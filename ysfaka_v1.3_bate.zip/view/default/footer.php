


<footer data-am-widget="footer"
        class="am-footer am-footer-default"
        data-am-footer="{  }">
    <div class="am-footer-switch">
        友情链接：
        <span class="am-footer-divider"> | </span>
        <a id="godesktop" data-rel="desktop" class="am-footer-desktop" href="http://www.yunscx.com" target="_blank">
            云尚官网
        </a>
    </div>
    <div class="am-footer-miscs ">

        <p>由 <a href="http://www.yunscx.com/" title="云尚创想"
                target="_blank" class="">云尚创想</a>
            提供技术支持</p>
        <p>CopyRight©2018  Yunscx Inc.</p>
        <p><?php echo $this->config['icpcode']?></p>
    </div>
</footer>




</body>

</html>
<script src="/static/default/assets/js/jquery.min.js"></script>
<script src="/static/default/assets/js/amazeui.min.js"></script>
<script src="/static/common/layer/layer.js"></script>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<?php echo $this->config['stacode']?>