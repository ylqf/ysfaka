### 什么是云尚发卡系统？
专门为个人或小型企业提供在线售卡，订单处理系统

### 程序使用要求？
* php >= 5.4
* mysql >= 5.2
* win or linux

### demo地址：[http://demo.yunscx.com](http://demo.yunscx.com/)

### 更多详细内容及配置教程请访问：
## [程序详情](http://www.yunscx.com/cms/a/ysfaka.html)

### BUG反馈、程序交流 QQ群：568679748

### 关于作者

```php
  return [
    $nickName  : "ashang",
    $site : "http://utf8.hk"
  ]
```